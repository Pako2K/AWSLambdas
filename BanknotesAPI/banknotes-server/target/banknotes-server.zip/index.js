"use strict"

const { execAPI } = require('./api/controller');

exports.handler = async function(event, context) {

    console.log(`Request received: ${JSON.stringify(event.requestContext.http)}`);

    // Call API
    try {
        const result = await execAPI(event);
        const resultStr = JSON.stringify(result)
        console.log(`Reply: ${resultStr}`);
        return {
            statusCode: 200,
            body: resultStr
        };
    } catch (err) {
        console.error(`Error: ${JSON.stringify(err)}`);
        return {
            statusCode: err.status,
            body: JSON.stringify({ exception: err.exception })
        };
    }
};