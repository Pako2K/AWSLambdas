"use strict";

const { LambdaClient, InvokeCommand } = require(process.env.CLIENT_LAMBDA_MOCK || "@aws-sdk/client-lambda");

const CLIENT_CONFIG = {};

const COMMAND_PARAMS = {
    FunctionName: "",
    InvocationType: "RequestResponse",
};

const OP_MAPPING = {
    continentsGET: "banknotes-continents-get",
    territoryTypesGET: "banknotes-territorytypes-get"
}


exports.route = async function(operation) {
    const client = new LambdaClient(CLIENT_CONFIG);
    COMMAND_PARAMS.FunctionName = OP_MAPPING[operation];
    //COMMAND_PARAMS.Payload = '{"msg": "Input from the caller"}';
    const command = new InvokeCommand(COMMAND_PARAMS);

    const responseEncoded = await client.send(command);
    const respStr = new TextDecoder().decode(responseEncoded.Payload)

    return JSON.parse(respStr);
}