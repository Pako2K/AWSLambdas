"use strict";

const yaml = require('yamljs');
const JSONValidator = require('jsonschema').Validator;

const { route } = require('./router');

const OAS_FILE = "./api/banknotes-api.yaml";


exports.execAPI = async function(event) {
    const [operationId, requestSchema, responseSchema, validator] = lookupAPI(event);

    // Excecute operation
    try {
        const result = await route(operationId);
        const validation = validator.validate(result, responseSchema);
        if (validation.valid) return result;
        else throw { code: 5001, message: `Invalid Response: ${JSON.stringify(result)}. Errors: ${validation.errors}` }
    } catch (err) {
        const exc = exception(500, err.code, err.message);
        throw exc;
    }
}

function lookupAPI(event) {

    let oasFile;
    try {
        // Read OAS file
        oasFile = yaml.load(OAS_FILE);
        // The validator caanot handle '#' in the refernces
        oasFile = JSON.parse(JSON.stringify(oasFile).replace(/\$ref":"#/g, '$ref":"'));
    } catch (err) {
        console.error(err);
        throw exception(500, err.code, err.message);
    }

    let method;
    let path;
    if (event.requestContext && event.requestContext.http) {
        method = event.requestContext.http.method.toLowerCase();
        path = event.requestContext.http.path;
    }

    const pathOAS = oasFile.paths[path];
    if (!pathOAS) throw exception(404, "404", "Resource not found");

    const methodOAS = pathOAS[method];
    if (!methodOAS) throw exception(404, "404", "Resource/Operation not found");

    const operationId = methodOAS.operationId
    if (!operationId) throw exception(500, "500", "OAS Operation not defined!");

    let reqSchema = {};
    let repSchema = {};

    try {
        reqSchema = methodOAS["requestBody"]["content"]["application/json"]["schema"];
    } catch (err) {
        console.info("No Request schema found");
    }

    try {
        repSchema = methodOAS["responses"]["200"]["content"]["application/json"]["schema"];
    } catch (err) {
        console.info("No Response schema found");
    }

    return [operationId, reqSchema, repSchema, setValidator(oasFile)];
}


function setValidator(oasFile) {
    const validator = new JSONValidator();

    // Load all the schemas
    const allSchemas = oasFile["components"] ? oasFile["components"]["schemas"] : [];
    for (let schemaName of Object.keys(allSchemas))
        validator.addSchema(allSchemas[schemaName], "/components/schemas/" + schemaName);

    return validator;
}


function exception(status, code, msg) {
    return {
        status: status,
        exception: {
            code: code,
            description: msg
        }
    };
}